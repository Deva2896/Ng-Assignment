import { Component, Input } from '@angular/core';
import {MatStepperModule} from '@angular/material/stepper';
import {MatTableModule} from '@angular/material/table';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  @Input() dataSource ;
  title = 'NgAssignment';
  try :boolean = false;
  showMe:boolean =true;
  displayedColumns: string[] = ['FullName', 'Email', 'Cell', 'Speciality','PracticeName','Adddress','city','State','ZipCode'];


  tryDemo(){
    console.log(this.dataSource)
    this.try = true;
    this.showMe = false;
  }

}
